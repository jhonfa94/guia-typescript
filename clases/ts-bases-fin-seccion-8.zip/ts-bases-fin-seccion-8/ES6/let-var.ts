(() => {

    // console.log(a);

    const nombre: string = 'Fernando'

    const getName = (): void => {
        console.log('viejo getName');
    }

    // getName = () => { console.log('Nuevo getName') };
    // getName()

})()